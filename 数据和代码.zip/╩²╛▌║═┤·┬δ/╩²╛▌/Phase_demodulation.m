clear all;
z=500;                       %探测器的距离（平顶光束旋转点为原点）单位mm
z0=0;                        %高斯光束的位置
a = 0;
%a=linspace(-4e-4,4e-4,11);   %角度

p0 = 3;
n=1000;                      %总采样点数
l=2.5;                       %探测器尺寸
r=0.5;                       %平面波轮廓半径
gap=10e-3;                   %探测器间隙宽度
dn=gap/(2*l)*n;
nn=(n-dn)/2;
t = linspace(0,0.01,101);

lambda=1.064e-3;             %波长
f = 3e11/lambda;             %频率
f_0 = 1e3;                     %频率差
k=2*pi/lambda;               %波数
w0=0.5;                      %束腰

%像差设置
% Display the Zernike function Z(n=5,m=1)

x = linspace(-1,1,1000);
[X,Y] = meshgrid(x,x);
[theta,r] = cart2pol(X,Y);
idx = r<=1;
Aber = nan(size(X));
ff1 = [[0,0];[1,1];[1,-1];[2,2];[2,0];[2,-2];[3,3];[3,1];[3,-1];[3,-3];[4,4];[4,2];[4,0];[4,-2];[4,-4]];

for i = 1:15
    
    Aber(idx) = zernfun(ff1(i,1),ff1(i,2),r(idx),theta(idx));%初级球差
    Aber = Aber*1.064/100;
    data{i} = Aber;
%     figure(1)
%     subplot(4,4,i);
%     pcolor(x,x,Aber), shading interp
%     axis  square,  colorbar
%     title('Zernike function Z_4^0(r,\theta)')
end
%     %复振幅求相位
%     % F=plane_E.*conj(plane_E1);
%     z=500;                       %探测器的距离（平顶光束旋转点为原点）单位mm
%     z0=0;                        %高斯光束的位置
%     a = 0;
%     %a=linspace(-4e-4,4e-4,11);   %角度
% 
%     p0 = 3;
%     n=1000;                      %总采样点数
%     l=2.5;                       %探测器尺寸
%     r=0.5;                       %平面波轮廓半径
%     gap=10e-3;                   %探测器间隙宽度
%     dn=gap/(2*l)*n;
%     nn=(n-dn)/2;
%     t = linspace(0,0.001,101);
% 
%     lambda=1.064e-3;             %波长
%     f = 3e11/lambda;             %频率
%     f_0 = 1e3;                     %频率差
%     k=2*pi/lambda;               %波数
%     w0=0.5;                      %束腰
%     
%     m=length(t);
%     A = zeros(1,m); 
%     LPF=zeros(1,m);
%     p1 = zeros(1,m);
%     p2 = zeros(1,m);
%     sAP=zeros(1,m);
%     Aber_x = [];
%  for ii = 1:15
%      Aber_x = data{ii};
%      tt = 1;
% %     for tt = 1:m
%       %光束设置 
%       gaussian_E = f_Gaussian_beams(w0,z,l,n,n)*exp(2i*pi*f*t(tt)); 
% %       plane_E1 = f_plane_wave(z,z0,l,n,n,a,0)*exp(2i*pi*f*t(tt));
%       plane_E=f_plane_wave(z,z0,l,n,n,a,p0)*exp(2i*pi*(f+f_0)*t(tt))+Aber_x;
%       % plane_E1=f_plane_wave(z,z0,l,n,n,a,0);
%       F=gaussian_E.*conj(plane_E);
%       %F=gaussian_E.*conj(plane_E);                     %复振幅相乘
%       %LPF(ii)=nansum(nansum(F));
%       B1=mat2cell(F,[nn dn nn],[nn dn nn]);       %将矩阵分解为元胞
%       B2=cellfun(@nansum,cellfun(@nansum,B1,'UniformOutput',false));
%       B3=angle(B2);
%       LPF(ii)=B2(1,1)+B2(1,3)+B2(3,1)+B2(3,3);
%       sAP(ii)=B3(1,1)+B3(1,3)+B3(3,1)+B3(3,3);
%     
%     p1 = angle(LPF);
%     p2 = sAP/4;
%     figure(2)
%     subplot(4,4,ii);
%     plot(p1)
% %     subplot(4,4,i);
% %     plot(p2)
% %     mean(p1(:))
%  end
 

%正交解调求相位
m=length(t);
p3 = zeros(1,m);
I1=zeros(1,m);
sAP1=zeros(1,m);
b5=zeros(1,m);
I_SIN=zeros(1,m);
p4 = zeros(1,15);
% [x1,y1]=meshgrid(linspace(-r,r,n),li0nspace(-r,r,n));
for ii = 1:100
    x1=rand(1,15);y1=sum(x1);r1=x1/y1;
  Aber_x = (data{2}*r1(2)+data{3}*r1(3)+data{4}*r1(4)+data{6}*r1(6)+data{7}*r1(7)+data{8}*r1(8)+data{9}*r1(9)+data{10}*r1(10)+data{11}*r1(11)+data{12}*r1(12)+data{14}*r1(14)+data{15}*r1(15))*2;
%   Aber_x = (data{1}*r1(1)+data{2}*r1(2)+data{3}*r1(3)+data{4}*r1(4)+data{5}*r1(5)+data{6}*r1(6)+data{7}*r1(7)+data{8}*r1(8)+data{9}*r1(9)+data{10}*r1(10)+data{11}*r1(11)+data{12}*r1(12)+data{13}*r1(13)+data{14}*r1(14)+data{15}*r1(15))*2;
%     Aber_x = (data{13}+3*data{5}+2*data{1})/6*2;%球差
%   Aber_x = (data{8}+2*data{2}+2*data{3}+data{9})/6*ii;%慧差
%   Aber_x = data{5}*ii;%子午像散
%   Aber_x = data{6}*ii;%弧矢像散
%   Aber_x = ((data{13}+3*data{5}+2*data{1})/6*ii+(data{8}+2*data{2}+2*data{3}+data{9})/6*ii*10)/11;%1球差+2慧差
    for tt = 1:m
      %光束设置 
%        Aber_x = data{13}+3*data{5}+2*data{1};
%     %   Aber_x = data{14}+3*data{6};
%       figure(1)
%       pcolor(x,x,Aber_x), shading interp
%       axis  square,  colorbar
%       title('球差')
      gaussian_E = f_Gaussian_beams(w0,z,l,n,n).*exp(2i*pi*f*t(tt)); 
      plane_E=(f_plane_wave(z,z0,l,n,n,a,p0)+Aber_x)*exp(2i*pi*(f+f_0)*t(tt));
    %   plane_E1 = f_plane_wave(z,z0,l,n,n,a,0).*exp(2i*pi*f*t(tt));
      Interference_E = plane_E+gaussian_E;
    %   Interference_E = plane_E+plane_E1;
      Interference_I = real(abs(Interference_E).^2);
    %   Interference_I = abs(Interference_E).^2;

      B3=mat2cell(Interference_I,[nn dn nn],[nn dn nn]);       %将矩阵分解为元胞
      B4=cellfun(@nansum,cellfun(@nansum,B3,'UniformOutput',false));
      I1(tt)=real(B4(1,1)+B4(1,3)+B4(3,1)+B4(3,3));

    

    Icos=I1.*cos(2*pi*f_0*t);
    Isin=I1.*sin(2*pi*f_0*t);

    cos1 = sum(Icos);
    sin1 = sum(Isin);
    
    p4(ii) = -atan(sin1/cos1);           %解调出的相位信息（）
    end
end
plot(p4)
save('Test1','p4')
title('Test1')
