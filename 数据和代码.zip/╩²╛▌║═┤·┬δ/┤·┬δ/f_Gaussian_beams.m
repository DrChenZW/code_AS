%***********************高斯光束产生函数**************************
function Gaussian_E = f_Gaussian_beams(w0,z,R,Nx,Ny)
%   w0:     束腰半径
%   z:      传输距离
%   lamda:  波长
%   x_length: 观察屏x方向长度
%   y_length: 观察屏y方向长度
%   Nx，Ny: x,y方向等分割数目
%   Gaussian_I: 输出光强分布
%   p0为初始相位
lamda = 1.064e-6;
[x,y]=meshgrid(linspace(-R,R,Nx),linspace(-R,R,Ny));

D1=(x.^2+y.^2).^(1/2);     %采样圆
%%消除采样圆外值
li=find(D1>=R);
x(li) = nan;
y(li) = nan;
k = 2*pi/lamda;     %波数


zR = pi*(w0^2)/lamda;       % 瑞利长度
w_z = w0*sqrt(1+(z/zR)^2);  % z位置的光束半径
E0 = 1;                     % 振幅系数定义为1
q = z-zR*1i;
Gaussian_E = (w0/w_z).*exp(1i*k.*(0.5.*(x.^2+y.^2)./q+z));
end