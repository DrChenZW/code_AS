clc
clear all
% load('spherical.mat')
% A = p4;
% load('coma.mat');
% B = p4;
% load('Monte Carlo1.mat');
% C = p4;
% load('Monte Carlo2.mat');
% D = p4;
B=[];
load('lamda00N11.mat');
A = p4.';
load('lamda20N002.mat');
B(:,1) = p4.';
C(:,1) = abs(B(:,1)-A);
load('lamda20N004.mat');
B(:,2) = p4.';
C(:,2) = abs(B(:,2)-A);
load('lamda20N006.mat');
B(:,3) = p4.';
C(:,3) = abs(B(:,3)-A);
load('lamda20N008.mat');
B(:,4) = p4.';
C(:,4) = abs(B(:,4)-A);
load('lamda20N010.mat');
B(:,5) = p4.';
C(:,5) = abs(B(:,5)-A);
load('lamda20N012.mat');
B(:,6) = p4.';
C(:,6) = abs(B(:,6)-A);
load('lamda20N014.mat');
B(:,7) = p4.';
C(:,7) = abs(B(:,7)-A);
load('lamda20N016.mat');
B(:,8) = p4.';
C(:,8) = abs(B(:,8)-A);
load('lamda20N018.mat');
B(:,9) = p4.';
C(:,9) = abs(B(:,9)-A);
load('lamda20N02.mat');
B(:,10) = p4.';
C(:,10) = abs(B(:,10)-A);
C(C>1)=0;

Fs=2;
load('lamda30N11.mat');
D = p4;
E = abs(D-A);
E(E>1)=0;

for i=1:10
    [psd(:,i),f] = periodogram(C(:,i),rectwin(length(C(:,i))),length(C(:,i)),Fs);
    PSD(:,i) = (psd(:,i).^0.5/(2*pi))*1.064e6/10;
end

x2 = {'1%' '2%' '3%' '4%' '5%' '6%' '7%' '8%' '9%' '10%'};
boxplot(PSD,'symbol','')
grid on;
set(gca,'xtick',1:1:10);
set(gca,'xticklabel',x2(1:end));
set(gca,'YLim',[0 10]);%y轴的数据显示范围
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
ylabel('pm/sqrt(Hz)'); % 给左y轴添加轴标签

% plot(A,'--*r')
% hold on
% plot(B,'--+b')
% grid on;
% set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
% xlabel('Aberration size（λ/100-λ）');
% ylabel('Phase/rad');
% % title('球差与慧差对相位的影响')
% legend('spherical','coma');


% 
% plot(C,'r')
% hold on
% plot(D,'b')
% grid on;
% set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
% xlabel('random times');
% ylabel('Phase/rad');
% % title('随机像差对相位的影响')
% legend('Contains symmetrical aberrations','Does not contain symmetrical aberrations');

% E1 = mean(C);
% E2 = mean(D);
% V1 = var(C);
% V2 = var(D);
x=1:12;
x1 = {'λ'	'λ/5'	'λ/10'	'λ/15'	'λ/20'	'λ/25'	'λ/30'	'λ/40'	'λ/50'	'λ/60'	'λ/70'	'λ/80'};
y1=[0.1293	 0.0257	0.0129	 0.0086	 0.0065	0.0051	0.0042	0.0043	0.0026	0.0021	0.0018	0.0016];
y2=[5.7921e03	1.1422e03	572.5082	383.4959	287.8198	229.3470	190.7832	144.4334	114.2118	95.4105	81.4221	71.2404];

% yyaxis left; % 激活左边的轴
% plot(x,y1,'-o','linewidth',1);
% % title('Title');
% legend('基于XXX的算法','基于YYY的算法')
% set(gca,'xtick',1:1:12);
% set(gca,'xticklabel',x1(1:end));
% xlabel('Aberration size');
% ylabel('pm/sqrt(Hz)'); % 给左y轴添加轴标签
% grid on;
% set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);

yyaxis right; % 激活右边的轴
plot(x,y2,'-x','linewidth',1);
ylim([0,10000]); % 设置右y轴的界限
ylabel('pm/sqrt(Hz)'); % 给右y轴添加轴标签
grid on;
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
